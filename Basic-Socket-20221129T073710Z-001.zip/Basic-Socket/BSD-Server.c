#include<stdio.h>
#include<unistd.h>
#include<stdlib.h>
#include<sys/socket.h>
#include<netinet/in.h>
#include<arpa/inet.h>
#include<pthread.h>
#include<poll.h>
#include<sys/time.h>
#include<sys/types.h>
#include<sys/select.h>
#include<string.h>

int main()
{

int sfd;
int nsfd;
char buff[1024];
struct sockaddr_in addr;
addr.sin_family=AF_INET;
addr.sin_port=htons(8684);
sfd=socket(AF_INET,SOCK_STREAM,0);

addr.sin_addr.s_addr=inet_addr("127.0.0.2");
	 
int x=bind(sfd,(struct sockaddr *)&addr,sizeof(addr));
listen(sfd,10);
socklen_t len=sizeof(addr);

nsfd=accept(sfd,(struct sockaddr* )&addr,&len);

if(nsfd<0)
{
    printf("connection failed\n");
}
else
{
    printf("connection succesful\n");
}


x=recv(nsfd,buff,sizeof(buff),0);
printf("received message: %s\n",buff);
memset(buff,'\0',sizeof(buff));

printf("entre mssg to be sent\n");
scanf("%s",buff);

x=send(nsfd,buff,sizeof(buff),0);
printf("message sent succesful\n");



}