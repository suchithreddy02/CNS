#include<stdio.h>
#include<unistd.h>
#include<stdlib.h>
#include<sys/socket.h>
#include <sys/un.h>
#include <errno.h>
#include<netinet/in.h>
#include<arpa/inet.h>
#include<pthread.h>
#include<string.h>
#include<poll.h>
#define PORT 8684
int main( )
{
	struct sockaddr_in addr;
	
	
	int sfd;
	
	sfd=socket(AF_INET,SOCK_STREAM,0);
	
	if(sfd<0)
	{
		perror("socket error\n");
		exit(EXIT_FAILURE);
	}
	
	addr.sin_family=AF_INET;
	addr.sin_port=htons(PORT);
	addr.sin_addr.s_addr=inet_addr("127.0.0.2");
	
	if(connect(sfd,(struct sockaddr*)&addr,sizeof(addr))<0)
	{
		perror("connect failed");
		exit(EXIT_FAILURE);
	}
	
	char buff[1024];
	
	int n=1;
	
	
    printf("entre mssg to be sent\n");
    scanf("%s",buff);
    
    int x=send(sfd,buff,sizeof(buff),0);
    printf("message sent\n");
    memset(buff,'\0',sizeof(buff));

    x=recv(sfd,buff,sizeof(buff),0);
    printf("received message: %s\n",buff);

    close(sfd);
	
	return 0;
}